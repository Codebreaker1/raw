<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>CSS3 Bar Graphs</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		<link rel="stylesheet" type="text/css" href="styles/main.css"/>
	</head>
	<body>
		<!-- css bar graph -->
		<div class="css_bar_graph">
			
			<!-- y_axis labels -->
			<ul class="y_axis">
				<li>100%</li><li>40%</li><li>60%</li><li>40%</li><li>20%</li><li>0%</li>
			</ul>
			
			<!-- x_axis labels -->
			<ul class="x_axis">
				<li>0-8</li><li>8-12</li><li>12-18</li><li>18-30</li><li>30-50</li><li>50-100</li>
			</ul>
			
			<!-- graph -->
			<div class="graph">
				<!-- grid -->
				<ul class="grid">
					<li><!-- 100 --></li>
					<li><!-- 80 --></li>
					<li><!-- 60 --></li>
					<li><!-- 40 --></li>
					<li><!-- 20 --></li>
					<li><!-- 900 --></li>

					<li class="bottom"><!-- 0 --></li>
				</ul>
				
				<!-- bars -->
				<!-- 250px = 100% -->
				<ul>
					<li class="bar nr_1 blue" style="height: 125px;"><div class="top"></div><div class="bottom"></div><span>50%</span></li>
					<li class="bar nr_2 green" style="height: 225px;"><div class="top"></div><div class="bottom"></div><span>90%</span></li>
					<li class="bar nr_3 orange" style="height: 75px;"><div class="top"></div><div class="bottom"></div><span>30%</span></li>
					<li class="bar nr_4 purple" style="height: 100px;"><div class="top"></div><div class="bottom"></div><span>40%</span></li>
					<li class="bar nr_5 red" style="height: 150px;"><div class="top"></div><div class="bottom"></div><span>60%</span></li>
					<li class="bar nr_6 black" style="height: 150px;"><div class="top"></div><div class="bottom"></div><span>90%</span></li>

				</ul>	
			</div>
			
			<!-- graph label -->
			<div class="label"><span>Graph: </span>Gain (in percent)</div>
		
		</div>
	</body>
</html>