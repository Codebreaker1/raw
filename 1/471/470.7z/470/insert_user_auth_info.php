<?php include('header.php'); ?>
<?php include('dbconn.php'); ?>
<div class="content-wrapper" style="border-top: none; padding-left: 10px; width: 698px; padding-bottom: 82px;">

    <?php
    


        $query = "SELECT * FROM question"; 
        $sql = mysql_query($query) or die(mysql_error());
       
        while($row = mysql_fetch_array($sql) ){
 



         $asi =$row['Q_id'];
        // echo $asi;

         echo $_POST[$asi];
}
          
		//$city = $_POST["qualify"];
		
        //
		
	    
      
        
			
       // $query = "INSERT INTO user_auth(username, password, contact_num, email,prev) VALUES('$username', '$password', '$email', '$contactNumber', '$ad')";
           // $query = "INSERT INTO patient(age, blood, weight, food,location,exercise,gender) VALUES('$username', '$password','$asi', '$contactNumber', '$email','$ex', '$ad')"; 
         
        //$area = $inputs['area'];

        // Check if user_auth table is empty. If empty, then make the first logged in user as SUPER ADMIN. Else make this user as a NORMAL USER (member).
      
            
            // End checking.
        
        //$sql = mysql_query($query) or die(mysql_error());
      
                
            ?>
            <div class="alert alert-success">
                <script type="text/javascript">
                    function Redirect()
                    {
                        window.location="navigation.php";
                    }
                    document.write("Registration is successful, redirected to login page in 2 sec.");
                    setTimeout('Redirect()', 2000);
                </script>
            </div>
            <?php
        
    

    if (!$inputs) {
        echo '<a class="btn" href="registration.php">Go Back</a>';
    }
    ?> 
</div>
<?php include('footer.php'); ?>
