<?php include('header.php'); ?>
<?php include('dbconn.php'); ?>

<?php
error_reporting(0);
session_start();
if (!isset($_SESSION['user'])) {
    header('location:logout.php');
}
$userID = $_SESSION['id'];
$username = $_SESSION['user'];

//echo $username;

?>

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600' rel='stylesheet' type='text/css'>
<link href="//netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css" rel="stylesheet">
<head>
<link rel="stylesheet" type="text/css" href="a.css">
</head>


 <div class="testbox">
  <h1>Registration</h1>

    <form name="regiForm" class="form-horizontal" method="POST" onsubmit="return validateForm()" action="insert_user_auth_info.php">
      <hr>

      <?php
        $query = "SELECT * FROM question WHERE factor_id and Q_id IN(SELECT * FROM  `option` WHERE factor_id =1 AND Q_id =1) "; 
        $sql = mysql_query($query) or die(mysql_error());
       
while($row = mysql_fetch_array($sql) ){
    
      $asi=$row['factor_id'];

      ?>

    <label id="icon" for="name"><i class="icon-user"></i></label>
  <input type="text" name="<?php echo $row['Q_id']; ?>" id="username" placeholder="<?php echo $row['ques']; ?>" required/>


<?php  }?>

<?php

$query = "SELECT * FROM  `option` WHERE factor_id =1 AND Q_id =1"; 
        $sql = mysql_query($query) or die(mysql_error());

        while($row = mysql_fetch_array($sql) ){

        ?>
       
  
    <select name="cars" id="gender">
  <option value="<?php echo $row['option_id']; ?>"><?php echo $row['option']; ?></option>
    <option value="<?php echo $row['option_id']; ?>"><?php echo $row['option']; ?></option>

  
  </select>
<?php  }?>
 <button type="submit" class="button">Register</button>
</div>




<?php include('footer.php'); ?>